package locusta.project.entities;

public interface IEntity {
	public IEntity cloneForJson();
}
